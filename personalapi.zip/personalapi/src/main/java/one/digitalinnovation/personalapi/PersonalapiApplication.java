package one.digitalinnovation.personalapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonalapiApplication.class, args);
	}

}
