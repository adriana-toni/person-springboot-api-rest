package one.digitalinnovation.personalapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
